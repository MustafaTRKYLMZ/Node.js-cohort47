export const randomId = () => Math.floor(Math.random() * 1000000);
