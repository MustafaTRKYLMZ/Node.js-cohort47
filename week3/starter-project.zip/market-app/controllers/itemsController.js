export const getAllItems = async (req, res) => {
  res.status(500).json({ error: "Not implemented"});
}

export const createItem = async (req, res) => {
  res.status(500).json({ error: "Not implemented"});
}

export const updateItem = async (req, res) => {
  res.status(500).json({ error: "Not implemented"});
}

export const deleteItem = async (req, res) => {
  res.status(500).json({ error: "Not implemented"});
}
