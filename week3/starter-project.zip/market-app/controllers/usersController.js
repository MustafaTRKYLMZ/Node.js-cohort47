export const addUser = async (req, res) => {
  res.status(500).json({ error: "Not implemented"});
};

export const login = async (req, res) => {
  res.status(500).json({ error: "Not implemented"});
};
