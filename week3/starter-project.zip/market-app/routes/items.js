import express from "express";
import { getAllItems, createItem, updateItem, deleteItem } from "../controllers/itemsController.js";
const messagesRouter = express.Router();

// TODO: Add routes

export default messagesRouter;
