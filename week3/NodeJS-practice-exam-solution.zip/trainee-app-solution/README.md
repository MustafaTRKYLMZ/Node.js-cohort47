# Trainee application started code


## Setup
Please run `npm install`  

## Run
`node index.js`

